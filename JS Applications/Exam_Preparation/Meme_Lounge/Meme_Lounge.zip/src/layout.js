import { html } from "../node_modules/lit-html/lit-html.js";

export const layoutTemplate = (userData, content) => html`


  
`;