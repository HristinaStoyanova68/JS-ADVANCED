import page from '../node_modules/page/page.mjs';
import { updateInfo } from '../app.js';
import { html, render } from '../node_modules/lit-html/lit-html.js';

const detailsTemplate = (furniture) => html`
<div class="row space-top">
            <div class="col-md-12">
                <h1>Furniture Details</h1>
            </div>
</div>
<div class="row space-top">
<div class="col-md-4">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <img src=${"../01.Furniture/" + furniture.img} />
                    </div>
                </div>
</div>
<div class="col-md-4">
                <p>Make: <span>${furniture.make}</span></p>
                <p>Model: <span>${furniture.model}</span></p>
                <p>Year: <span>${furniture.year}</span></p>
                <p>Description: <span>${furniture.description}</span></p>
                <p>Price: <span>${furniture.price}</span></p>
                <p>Material: <span>${furniture.material}</span></p>
                <div>
                    <a href="/edit/${furniture._id}" class="btn btn-info" style="display: ${furniture._ownerId == localStorage.ownerId ? 'inline' : 'none'}">Edit</a>
                    <a href="#" id=${furniture._id} class="btn btn-red" style="display: ${furniture._ownerId == localStorage.ownerId ? 'inline' : 'none'}" @click=${deleteFurniture}>Delete</a>
                </div>
            </div>
</div>
`;

const getDetails = (detailsId) => {

    return fetch(`http://localhost:3030/data/catalog/${detailsId}`)
        .then(res => res.json());
};

export const detailsView = (ctx) => {
    getDetails(ctx.params.detailsId)
        .then(furniture => render(detailsTemplate(furniture), document.querySelector('.container')))
};

const deleteFurniture = (event) => {

const id = event.target.id;

fetch(`http://localhost:3030/data/catalog/${id}`, {
    method: 'delete',
    headers: {
        'X-Authorization': localStorage.token,
    }
});
page.redirect('/catalog');
}

