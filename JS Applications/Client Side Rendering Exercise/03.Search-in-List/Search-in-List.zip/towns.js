export const towns = [
    'Sofia',
    'Pleven',
    'Varna',
    'Plovdiv',
    'Dolna Bania',
    'Gorna Bania'
];